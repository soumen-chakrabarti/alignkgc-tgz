import os

dataset = 'data/DBP15k'
pairs = ['fr_en', 'ja_en', 'zh_en']

for pair in pairs:
    print('Running experiment for', pair)
    os.system(f'python -W ignore main.py --dataset {dataset} --lang {pair}')
