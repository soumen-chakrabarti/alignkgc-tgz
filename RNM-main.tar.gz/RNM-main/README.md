# RNM

Relation-Aware Neighborhood Matching Model for Entity Alignment (AAAI 2021)
https://arxiv.org/abs/2012.08128

## Environment Setup

```
conda create --name rnm-conda python=3.6
conda activate rnm-conda
pip install tensorflow==1.14.0
```

## Dataset

Please refer to [data](https://drive.google.com/file/d/1Ya1S-SXdCZkCjAlibf4NIr-1t0n8uB0-/view?usp=sharing)

## Run
```sh
python main.py --dataset /path/to/DBP15k --lang [fr_en/ja_en/zh_en]
```

Non-default hyperparameters can be set by editing the Config class or by passing values using command 
line arguments.

Usage is as follows:
```text
usage: main.py [-h] [--dataset DATASET] [--lang LANG] [--epochs EPOCHS]
               [--pre_epochs PRE_EPOCHS] [--train_batchnum TRAIN_BATCHNUM]
               [--gamma GAMMA] [--lam_e LAM_E] [--lam_r LAM_R] [--dim DIM]
               [--seed SEED] [--random_state RANDOM_STATE]
```
Note: The `dataset` and `lang` arguments are mandatory.

## Queing multiple runs or configuring grid-search

`run.py` gives an example script that can be modified to queue multiple RNM runs with various configurations.
