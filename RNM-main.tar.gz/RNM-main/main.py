import tensorflow as tf
import argparse
from include.Config import Config
from include.Model import build, training, get_nbr
from include.Load import *

import os
os.environ["TF_CPP_MIN_LOG_LEVEL"] = "3"

import sys
class Logger(object):
    def __init__(self, file_path):
        self.terminal = sys.stdout
        if os.path.isfile(file_path):
            os.remove(file_path)
        self.log = open(file_path, "a")
   
    def write(self, message):
        self.terminal.write(message)
        self.log.write(message)  

    def flush(self):
        pass

parser = argparse.ArgumentParser()
parser.add_argument('--dataset', type=str, help='path/to/dir/containing/lang/pairs/')
parser.add_argument('--lang', type=str, help='zh_en, ja_en and fr_en')
parser.add_argument('--epochs', type=int, default=None)
parser.add_argument('--pre_epochs', type=int, default=None)
parser.add_argument('--train_batchnum', type=int, default=None)
parser.add_argument('--gamma', type=float, default=None)
parser.add_argument('--lam_e', type=float, default=None)
parser.add_argument('--lam_r', type=float, default=None)
parser.add_argument('--dim', type=int, default=None)
parser.add_argument('--seed', type=int, default=None)
parser.add_argument('--random_state', type=int, default=12306)


args = parser.parse_args()

np.random.seed(args.random_state)
tf.set_random_seed(args.random_state)

logpath = './logs/'
if not os.path.exists(logpath):
    os.makedirs(logpath)

logname = [args.dataset.rstrip('/').split('/')[-1]+'_'+args.lang]
skipkeys = ['dataset', 'lang', 'random_state']
for k, v in vars(args).items():
    if v is not None and k not in skipkeys:
        logname.append(f'{k}-{v}')
logname = '_'.join(logname)+'.log'
sys.stdout = Logger(os.path.join(logpath, logname))

if __name__ == '__main__':
    config = Config(dataset=args.dataset, language=args.lang)

    for k, v in vars(args).items():
        if k in config.__dict__ and v is not None:
            config.__dict__[k] = v

    print(f'Config:\n{config.__dict__}')

    e1 = set(loadfile(config.e1, 1))
    e2 = set(loadfile(config.e2, 1))
    e = len(e1 | e2)

    ILL = loadfile(config.ill, 2)
    illL = len(ILL)
    np.random.shuffle(ILL)
    train = np.array(ILL[:int(illL * config.seed / 100)])
    test = ILL[int(illL * config.seed / 100):]
    
    ILL_r = loadfile(config.ill_r, 2)
    
    KG1 = loadfile(config.kg1, 3)
    KG2 = loadfile(config.kg2, 3)
    
    r_kg_1 = set()
    r_kg = set()

    for tri in KG1:
        r_kg_1.add(tri[1])
        r_kg.add(tri[1])
    
    for tri in KG2:
        r_kg.add(tri[1])
    
    output_h, output_r, loss_pre, loss_all, M0, rel_type  = \
        build(config.dim, config.act_func, config.gamma, config.k, config.vec, e, KG1 + KG2)
    training(output_h, loss_pre, loss_all, config.lr, config.epochs, config.pre_epochs, train, e,
                         config.k, config.save_suffix, config.dim, config.train_batchnum, test, M0, 
                         e1, e2, KG1 + KG2, rel_type, output_r, len(r_kg_1), len(r_kg), ILL_r, config.lam_e, config.lam_r)
    