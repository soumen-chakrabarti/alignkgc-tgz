import tensorflow as tf
import os


class Config():
    def __init__(self, dataset='', language=''):
        prefix = os.path.join(dataset, language)
        self.kg1 = os.path.join(prefix, 'triples_1')
        self.kg2 = os.path.join(prefix, 'triples_2')
        self.e1 = os.path.join(prefix, 'ent_ids_1')
        self.e2 = os.path.join(prefix, 'ent_ids_2')
        self.ill = os.path.join(prefix, 'ref_ent_ids')
        self.ill_r = os.path.join(prefix, 'ref_r_ids')
        self.vec = os.path.join(prefix, 'vectorList.json')
        self.save_suffix = dataset.rstrip('/').split('/')[-1]+'_'+language

        self.epochs = 60
        self.pre_epochs = 50
        self.train_batchnum=20
        self.test_batchnum=50

        self.dim = 300
        self.act_func = tf.nn.relu
        self.gamma = 1.0  # margin based loss
        self.k = 125  # number of negative samples for each positive one
        self.seed = 3  # 30% of seeds
        self.lr = 0.001
        self.lam_e = 10
        self.lam_r = 200
