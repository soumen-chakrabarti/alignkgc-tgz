import os
import argparse


# Hyper-parameters

ENTITY_NEIGH_MAX_NUM = 50 # max sampling neighbor num of entity
ENTITY_ATTVALUE_MAX_NUM = 50 #max sampling attributeValue num of entity
KERNEL_NUM = 21
SEED_NUM = 11037
CANDIDATE_NUM = 50 # candidate number

NEG_NUM = 5 # negative sampling num
LEARNING_RATE = 5e-4 # learning rate
MARGIN = 1 # margin
EPOCH_NUM = 200 # train epoch num

LOAD_BASIC_BERT_UNIT_MODEL_EPOCH_NUM = 4
BASIC_BERT_UNIT_MODEL_OUTPUT_DIM = 300


# The following should be set via command line or config file.

_BATCH_SIZE = 128 # train batch size

_CUDA_NUM = 0
""" GPU num """

_LANG2 = None
""" Language pair base data directory name, e.g., 
/path/to/fr_en or /path/toEN_FR_100K_V2"""


def get_argv():
    global _LANG2, _CUDA_NUM
    ap = argparse.ArgumentParser()
    ap.add_argument("--cuda_num", type=int,
                    default=0, help="CUDA number")
    ap.add_argument("--lang2", required=True,
                    help="/path/to/language/pair/directory/")
    av = ap.parse_args()
    _LANG2 = av.lang2
    _CUDA_NUM = av.cuda_num
    return av


def BATCH_SIZE():
    global _BATCH_SIZE
    return _BATCH_SIZE


def LANG():
    global _LANG2
    return _LANG2


def INTERACTION_MODEL_SAVE_PATH():
    global _LANG2
    return os.path.join(_LANG2, "interaction_model.bin")

#load model(base_bert_unit_model) path
def BASIC_BERT_UNIT_MODEL_SAVE_PATH():
    global _LANG2
    return _LANG2
                        
def BASIC_BERT_UNIT_MODEL_SAVE_PREFIX():
    return "basic_bert_model"

#load data path
def DATA_PATH():
    global _LANG2
    return _LANG2

#candidata_save_path
def TRAIN_CANDIDATES_PATH():
    return os.path.join(DATA_PATH(), 'train_candidates.pkl')

def TEST_CANDIDATES_PATH():
    return os.path.join(DATA_PATH(), 'test_candidates.pkl')

#entity embedding and attributeValue embedding save path.
def ENT_EMB_PATH():
    return os.path.join(DATA_PATH(),
                        '{}_emb_{}.pkl'.format(BASIC_BERT_UNIT_MODEL_SAVE_PREFIX(),
                                               LOAD_BASIC_BERT_UNIT_MODEL_EPOCH_NUM))

def ATTRIBUTEVALUE_EMB_PATH():
    return os.path.join(DATA_PATH(), 'attributeValue_embedding.pkl')

#1-1 match to attributeValue embedding.
def ATTRIBUTEVALUE_LIST_PATH():
    return os.path.join(DATA_PATH(), 'attributeValue_list.pkl')

#(candidate) entity_pairs save path.
#[(e1,ea),(e1,eb)...]
def ENT_PAIRS_PATH():
    return os.path.join(DATA_PATH(), 'ent_pairs.pkl')

#interaction feature save filepath name
#1-1 match to entity_pairs
def NEIGHBORVIEW_SIMILARITY_FEATURE_PATH():
    return os.path.join(DATA_PATH(), 'neighbor_view_similarity_feature.pkl')

#1-1 match to entity_pairs
def ATTRIBUTEVIEW_SIMILARITY_FEATURE_PATH():
    return os.path.join(DATA_PATH(), 'attribute_similarity_feature.pkl')

def DESVIEW_SIMILARITY_FEATURE_PATH():
    return os.path.join(DATA_PATH(), 'des_view_similarity_feature.pkl')
