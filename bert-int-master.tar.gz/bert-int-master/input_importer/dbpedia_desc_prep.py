import argparse
import logging
import os
import pickle
import re
from tqdm import tqdm
from urllib.request import urlopen
from bz2file import BZ2File


def key_val(text):
  try:
    key = re.search('<(.+?)>',text).group(1)
    value = re.search('"(.+)"',text).group(1)
    value = re.sub('\(.*\)','',value)
  except: 
    return None, None
  return key,value


def files_to_des_dict(filenames):
  des_dict_full = {}
  for filename in filenames:
    with open(filename) as f:
      content = f.read()
    for line in tqdm(content.split('\n')):
      key, value = key_val(line)
      if key is None or value is None: continue
      des_dict_full[key] = value
  return des_dict_full


def urls_to_des_dict(urls):
  """Reads DBPedia abstracts and returns a dict with key=URN, value=abstract."""
  des_dict = dict()
  for url in urls:
    logging.info("Fetching %s", url)
    assert url.endswith("bz2")
    fp = urlopen(url)
    zp = BZ2File(fp)
    pbar = tqdm(unit=" lines")
    while True:
      line = zp.readline().decode("utf-8")
      if line is None or not line: break
      if line.startswith("#"): continue
      try:
        key, val = key_val(line)
        if key is None or val is None: continue
        des_dict[key] = val
      except:
        logging.fatal("%s", line)
        raise ValueError
      pbar.update(1)
    zp.close()
    logging.info("description dict size %d", len(des_dict))
  return des_dict


def get_entity_lists(ent_list):
  lang1_links = []
  lang2_links = []
  
  with open(ent_list) as f:
    content = f.read()
  
  for line in content.split('\n'):
    line = line.split('\t')
    if len(line) == 2:
      lang1_links.append(line[0])
      lang2_links.append(line[1])
  
  return lang1_links,lang2_links


def get_entity_dict(ent_lists, des_dict):
  bertint_des_dict = {}

  for i, ent_links in enumerate(ent_lists):
    bad_cnt = 0
    for url in tqdm(ent_links):
      try:  
        bertint_des_dict[url] = des_dict[url]
      except:
        bad_cnt+=1
    print('Bad links in lang',i+1,': ',bad_cnt)
  
  return bertint_des_dict


def add_desc_one(ent_links_path, des_dict_from, desc_to_path):
  lang1_links, lang2_links = get_entity_lists(ent_links_path)
  bertint_des_dict = get_entity_dict([lang1_links, lang2_links], des_dict_from)
  logging.info("Saving %s", desc_to_path)
  with open(desc_to_path, 'wb') as f:
    pickle.dump(bertint_des_dict,f)


def main():
  logging.getLogger().setLevel(logging.INFO)
  
  dbp_urls = [
    "http://downloads.dbpedia.org/2016-10/core-i18n/en/long_abstracts_en.tql.bz2",
    "http://downloads.dbpedia.org/2016-10/core-i18n/de/long_abstracts_de.tql.bz2",
    "http://downloads.dbpedia.org/2016-10/core-i18n/fr/long_abstracts_fr.tql.bz2"
  ]

  lang12_subdirs = [
    "EN_DE_100K_V1", "EN_DE_100K_V2", "EN_DE_15K_V1", "EN_DE_15K_V2",
    "EN_FR_100K_V1", "EN_FR_100K_V2", "EN_FR_15K_V1", "EN_FR_15K_V2",
  ]

  ap = argparse.ArgumentParser()
  ap.add_argument('--dbpedia', nargs='*', default=dbp_urls,
                  help='Dbpedia URLs in various languages')
  ap.add_argument('--openea', required=True,
                  help='/path/to/openea/download/dir/')
  ap.add_argument('--bertint', required=True,
                  help='/path/to/openea/prepared/for/bertint/dir/')
  av = ap.parse_args()

  desc_pickle_from = os.path.join(av.bertint, "dbpedia_desc.pkl")
  if not os.access(desc_pickle_from, os.R_OK):
    logging.warn("Cannot read %s", desc_pickle_from)
    des_dict_from = urls_to_des_dict(av.dbpedia)
    with open(desc_pickle_from, 'wb') as f:
      pickle.dump(des_dict_from, f)
  else:
    logging.info("Found %s", desc_pickle_from)
    with open(desc_pickle_from,'rb') as f:
      des_dict_from = pickle.load(f)

  for lang12_subdir in lang12_subdirs:
    logging.info("%s", lang12_subdir)
    lang12_from = os.path.join(av.openea, lang12_subdir)
    lang12_entlinks = os.path.join(lang12_from, "ent_links")
    lang12_desc_pickle_to = os.path.join(av.bertint, lang12_subdir, "desc_dict.pkl")
    add_desc_one(lang12_entlinks, des_dict_from, lang12_desc_pickle_to)


if __name__ == '__main__':
  main()
