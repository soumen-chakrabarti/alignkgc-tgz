import os
import argparse
import logging


def get_align_pairs(infile):
  with open(infile) as f:
    content = f.read()

  align_pair = []
  for line in content.split('\n'):
    line = line.split('\t')
    if len(line) == 2:
      align_pair.append(line)

  return align_pair


def get_ent2index(align_pair):
  ent2index = {}

  for i in range(len(align_pair)):
    a,b = align_pair[i]
    
    ent2index[a] = str(i)
    ent2index[b] = str(len(align_pair)+i)
  
  return ent2index


def create_ent_lists(outfile1,outfile2,align_pair,ent2index):
  ent_1 = []
  ent_2 = []
  
  for i in range(len(align_pair)):
    a,b = align_pair[i]

    ent_1.append('\t'.join([str(i),a])+'\n')
    ent_2.append('\t'.join([str(len(align_pair)+i),b])+'\n')

  with open(outfile1,'w') as f:
    f.writelines(ent_1)
  with open(outfile2,'w') as f:
    f.writelines(ent_2)


def get_align_id_pairs(align_pair,ent2index):
  align_id_pair = []

  for a,b in align_pair:
    align_id_pair.append(ent2index[a]+'\t'+ent2index[b]+'\n')

  return align_id_pair


def create_train_test_files(trainfile, testfile, align_id_pair):
  train_data = align_id_pair[:len(align_id_pair)//3]
  test_data = align_id_pair[len(align_id_pair)//3:]

  with open(trainfile,'w') as f:
    f.writelines(train_data)
  with open(testfile,'w') as f:
    f.writelines(test_data)


def convert_attr_info(infile,outfile):
  with open(infile,'r') as f:
    content = f.read()
  content = content.split('\n')
  outlist = []
  for line in content:
    line = line.split('\t')
    if len(line) == 3:
      a,b,c = line
      a = '<'+a+'>'
      b = '<'+b+'>'
      outlist.append('\t'.join([a,b,c])+'\n')
  with open(outfile,'w') as f:
    f.writelines(outlist)


def get_rel2id(filenames):
  rel2id = {}
  relation_set = set()

  for filename in filenames:
    with open(filename) as f:
      content = f.read()

    for line in content.split('\n'):
      line = line.split()
      if len(line) != 3:
        continue
      relation_set.add(line[1])

  for i,rel in enumerate(relation_set):
    rel2id[rel] = str(i)

  return rel2id


def convert_text_triples_to_idx_triples(infile,outfile,ent2index,rel2id):
  triple_list = []
  with open(infile) as f:
    content = f.read()

  for line in content.split('\n'):
    line = line.split()
    if len(line) != 3:
      continue
    triple_list.append(ent2index[line[0]]+'\t'+rel2id[line[1]]+'\t'+ent2index[line[2]]+'\n')
  
  with open(outfile,'w') as f:
    f.writelines(triple_list)


def convert_relation_tuple_to_idx_tuple(infile, outfile, rel2id):
  rel_ids = []
  with open(infile) as f:
    content = f.read()

  for line in content.split('\n'):
    line = line.split()
    if len(line) != 3:
      continue
    rel_ids.append(rel2id[line[1]]+'\t'+line[1]+'\n')

  with open(outfile,'w') as f:
    f.writelines(rel_ids)


def convert_one_pair(source_dir, dest_dir):
  align_pair = get_align_pairs(os.path.join(source_dir, 'ent_links'))
  ent2index = get_ent2index(align_pair)
  align_id_pair = get_align_id_pairs(align_pair,ent2index)
  rel2id = get_rel2id([os.path.join(source_dir, 'rel_triples_1'),
                       os.path.join(source_dir, 'rel_triples_2')])
  create_ent_lists(os.path.join(dest_dir, 'ent_ids_1'),
                   os.path.join(dest_dir, 'ent_ids_2'),
                   align_pair, ent2index)
  create_train_test_files(os.path.join(dest_dir, 'sup_pairs'),
                          os.path.join(dest_dir, 'ref_pairs'),
                          align_id_pair)

  convert_attr_info(os.path.join(source_dir, 'attr_triples_1'),
                    os.path.join(dest_dir, 'en_att_triples'))
  convert_attr_info(os.path.join(source_dir, 'attr_triples_2'),
                    os.path.join(dest_dir, 'fr_att_triples'))

  convert_text_triples_to_idx_triples(os.path.join(source_dir, 'rel_triples_1'),
                                      os.path.join(dest_dir, 'triples_1'),
                                      ent2index, rel2id)
  convert_text_triples_to_idx_triples(os.path.join(source_dir, 'rel_triples_2'),
                                      os.path.join(dest_dir, 'triples_2'),
                                      ent2index, rel2id)

  convert_relation_tuple_to_idx_tuple(os.path.join(source_dir, 'rel_triples_1'),
                                      os.path.join(dest_dir, 'rel_ids_1'),
                                      rel2id)
  convert_relation_tuple_to_idx_tuple(os.path.join(source_dir, 'rel_triples_2'),
                                      os.path.join(dest_dir, 'rel_ids_2'),
                                      rel2id)


if __name__ == "__main__":
  logging.getLogger().setLevel(logging.INFO)
  ap = argparse.ArgumentParser()
  ap.add_argument("--openea", required=True, help="OpenEA base dir (in)")
  ap.add_argument("--bertint", required=True, help="Bert-int base dir (out)")
  av = ap.parse_args()

  for kgpair in os.scandir(av.openea):
    if not kgpair.is_dir(): continue
    dst_dir = os.path.join(av.bertint, kgpair.name)
    if not os.access(dst_dir, os.W_OK):
      logging.warning("creating %s", dst_dir)
      os.mkdir(dst_dir)
    logging.info("convert %s %s", kgpair.path, dst_dir)
    convert_one_pair(kgpair.path, dst_dir)

